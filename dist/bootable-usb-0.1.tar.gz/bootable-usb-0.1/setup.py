from setuptools import setup

setup(
    name='bootable-usb',
    version='0.1',
    scripts=['bootable-usb']
)
